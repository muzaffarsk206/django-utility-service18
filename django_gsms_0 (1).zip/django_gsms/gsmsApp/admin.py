from django.contrib import admin
from gsmsApp import models

# Register your models here.
admin.site.register(models.Petrol)
admin.site.register(models.Stock)
admin.site.register(models.Sale)

